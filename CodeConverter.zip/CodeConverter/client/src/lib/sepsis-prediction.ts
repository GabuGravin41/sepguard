import { type Vitals, type Patient } from '@shared/schema';

export interface ModelPrediction {
  modelName: string;
  prediction: number;
  confidence: number;
}

export interface SepsisRiskAssessment {
  riskScore: number;
  riskLevel: "low" | "moderate" | "high" | "critical";
  modelPredictions: ModelPrediction[];
  ensemblePrediction: number;
  recommendedActions: string[];
}

/**
 * Calculate sepsis risk based on patient vitals and demographics
 * Implementation based on the research data from the Kaggle notebooks
 */
export function calculateSepsisRisk(vitals: Vitals, patient: Patient): SepsisRiskAssessment {
  let riskScore = 0;
  
  // Age factor - research shows higher risk with age
  if (patient.age > 65) {
    riskScore += 15;
  } else if (patient.age > 50) {
    riskScore += 10;
  }
  
  // Gender factor (from research: sex_0male_1female where 0=male, 1=female)
  // Research indicates males have slightly higher risk
  if (patient.gender === 0) {
    riskScore += 5;
  }
  
  // Episode number factor - multiple episodes increase risk
  if (patient.episodeNumber > 1) {
    riskScore += 10;
  }
  
  // Heart rate factor (HR)
  if (vitals.heartRate) {
    if (vitals.heartRate > 100) {
      riskScore += 20;
    } else if (vitals.heartRate > 90) {
      riskScore += 10;
    }
  }
  
  // Temperature factor (Temp)
  if (vitals.temperature) {
    if (vitals.temperature > 38.5 || vitals.temperature < 36) {
      riskScore += 25; // Severe hypothermia or hyperthermia
    } else if (vitals.temperature > 37.5) {
      riskScore += 15; // Mild fever
    }
  }
  
  // Blood pressure factor (SBP)
  if (vitals.systolicBP) {
    if (vitals.systolicBP < 90) {
      riskScore += 20; // Hypotension
    } else if (vitals.systolicBP < 100) {
      riskScore += 10; // Low normal
    }
  }
  
  // Mean arterial pressure (MAP) - critical indicator from research
  if (vitals.meanArterialPressure) {
    if (vitals.meanArterialPressure < 65) {
      riskScore += 25; // Critical hypotension
    }
  }
  
  // Oxygen saturation factor (O2Sat)
  if (vitals.oxygenSaturation) {
    if (vitals.oxygenSaturation < 90) {
      riskScore += 25; // Severe hypoxemia
    } else if (vitals.oxygenSaturation < 95) {
      riskScore += 15; // Mild hypoxemia
    }
  }
  
  // Respiratory rate factor (Resp)
  if (vitals.respiratoryRate) {
    if (vitals.respiratoryRate > 22) {
      riskScore += 15; // Tachypnea
    }
  }
  
  // Ensure score is within 0-100 range
  riskScore = Math.max(0, Math.min(100, riskScore));
  
  // Determine risk level based on clinical thresholds
  let riskLevel: "low" | "moderate" | "high" | "critical";
  if (riskScore >= 85) {
    riskLevel = "critical";
  } else if (riskScore >= 65) {
    riskLevel = "high";
  } else if (riskScore >= 40) {
    riskLevel = "moderate";
  } else {
    riskLevel = "low";
  }

  // Simulate different ML model predictions with realistic variations
  // Based on the research notebooks: Logistic Regression, Random Forest, Neural Network
  const baseVariation = (Math.random() - 0.5) * 10; // -5 to +5 variation
  
  const modelPredictions: ModelPrediction[] = [
    { 
      modelName: "Logistic Regression", 
      prediction: Math.max(0, Math.min(100, riskScore + baseVariation)), 
      confidence: 0.92 
    },
    { 
      modelName: "Random Forest", 
      prediction: Math.max(0, Math.min(100, riskScore + baseVariation * 0.8)), 
      confidence: 0.87 
    },
    { 
      modelName: "Neural Network", 
      prediction: Math.max(0, Math.min(100, riskScore + baseVariation * 1.2)), 
      confidence: 0.85 
    },
  ];

  // Ensemble prediction as weighted average
  const ensemblePrediction = modelPredictions.reduce((sum, pred) => {
    return sum + (pred.prediction * pred.confidence);
  }, 0) / modelPredictions.reduce((sum, pred) => sum + pred.confidence, 0);

  // Generate recommended actions based on risk level
  const recommendedActions: string[] = [];
  
  switch (riskLevel) {
    case "critical":
      recommendedActions.push("Immediate medical attention required");
      recommendedActions.push("Contact attending physician");
      recommendedActions.push("Consider antibiotic therapy");
      recommendedActions.push("Increase monitoring frequency");
      break;
    case "high":
      recommendedActions.push("Monitor closely");
      recommendedActions.push("Consider additional testing");
      recommendedActions.push("Notify medical team");
      break;
    case "moderate":
      recommendedActions.push("Continue monitoring");
      recommendedActions.push("Review patient history");
      break;
    case "low":
      recommendedActions.push("Maintain current care plan");
      break;
  }

  return {
    riskScore,
    riskLevel,
    modelPredictions,
    ensemblePrediction,
    recommendedActions,
  };
}

/**
 * Validate vitals data for completeness and clinical ranges
 */
export function validateVitals(vitals: Partial<Vitals>): string[] {
  const errors: string[] = [];

  if (vitals.heartRate !== undefined && vitals.heartRate !== null) {
    if (vitals.heartRate < 30 || vitals.heartRate > 200) {
      errors.push("Heart rate must be between 30-200 BPM");
    }
  }

  if (vitals.temperature !== undefined && vitals.temperature !== null) {
    if (vitals.temperature < 30 || vitals.temperature > 45) {
      errors.push("Temperature must be between 30-45°C");
    }
  }

  if (vitals.systolicBP !== undefined && vitals.systolicBP !== null) {
    if (vitals.systolicBP < 50 || vitals.systolicBP > 300) {
      errors.push("Systolic BP must be between 50-300 mmHg");
    }
  }

  if (vitals.diastolicBP !== undefined && vitals.diastolicBP !== null) {
    if (vitals.diastolicBP < 30 || vitals.diastolicBP > 200) {
      errors.push("Diastolic BP must be between 30-200 mmHg");
    }
  }

  if (vitals.oxygenSaturation !== undefined && vitals.oxygenSaturation !== null) {
    if (vitals.oxygenSaturation < 70 || vitals.oxygenSaturation > 100) {
      errors.push("Oxygen saturation must be between 70-100%");
    }
  }

  if (vitals.respiratoryRate !== undefined && vitals.respiratoryRate !== null) {
    if (vitals.respiratoryRate < 5 || vitals.respiratoryRate > 60) {
      errors.push("Respiratory rate must be between 5-60 breaths/min");
    }
  }

  return errors;
}

/**
 * Generate realistic vital sign variations for simulation
 */
export function generateVitalVariation(baseValue: number, maxVariation: number, min: number, max: number): number {
  const variation = (Math.random() - 0.5) * 2 * maxVariation;
  const newValue = baseValue + variation;
  return Math.max(min, Math.min(max, Math.round(newValue * 10) / 10)); // Round to 1 decimal
}
