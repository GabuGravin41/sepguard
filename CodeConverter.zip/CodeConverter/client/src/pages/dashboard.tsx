import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useWebSocket } from '@/hooks/use-websocket';
import { useDarkMode } from '@/hooks/use-dark-mode';
import Sidebar from '@/components/dashboard/sidebar';
import Header from '@/components/dashboard/header';
import AlertsPanel from '@/components/dashboard/alerts-panel';
import StatsOverview from '@/components/dashboard/stats-overview';
import PatientMonitoringGrid from '@/components/dashboard/patient-monitoring-grid';
import AutomatedTestingPanel from '@/components/dashboard/automated-testing-panel';
import SensorStatusPanel from '@/components/dashboard/sensor-status-panel';
import AlertConfigPanel from '@/components/dashboard/alert-config-panel';
import VitalsChart from '@/components/dashboard/vitals-chart';
import ModelPredictionPanel from '@/components/dashboard/model-prediction-panel';
import ManualEntryPanel from '@/components/dashboard/manual-entry-panel';
import PatientDetailsModal from '@/components/dashboard/patient-details-modal';
import { type PatientWithVitals } from '@shared/schema';

export default function Dashboard() {
  const { isDark, toggleDarkMode } = useDarkMode();
  const [selectedPatient, setSelectedPatient] = useState<PatientWithVitals | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());

  // Fetch dashboard data
  const { data: patients = [], refetch: refetchPatients } = useQuery({
    queryKey: ['/api/patients'],
  });

  const { data: alerts = [], refetch: refetchAlerts } = useQuery({
    queryKey: ['/api/alerts'],
  });

  const { data: stats, refetch: refetchStats } = useQuery({
    queryKey: ['/api/stats'],
  });

  const { data: schedule, refetch: refetchSchedule } = useQuery({
    queryKey: ['/api/schedule'],
  });

  const { data: sensorStatus = [], refetch: refetchSensors } = useQuery({
    queryKey: ['/api/sensors'],
  });

  // WebSocket for real-time updates
  useWebSocket((message) => {
    switch (message.type) {
      case 'vitals_update':
      case 'automated_test_complete':
      case 'manual_test_complete':
        refetchPatients();
        refetchStats();
        break;
      case 'scheduler_status':
        refetchSchedule();
        break;
      case 'alert_generated':
        refetchAlerts();
        break;
    }
  });

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar 
        isDark={isDark} 
        onToggleDarkMode={toggleDarkMode}
        lastUpdate={currentTime}
      />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <Header currentTime={currentTime} />
        
        <div className="flex-1 overflow-auto p-6">
          <AlertsPanel alerts={alerts} onAcknowledgeAlert={refetchAlerts} />
          
          <StatsOverview stats={stats} />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PatientMonitoringGrid 
                patients={patients} 
                onSelectPatient={setSelectedPatient}
              />
            </div>
            
            <div className="space-y-6">
              {/* <AutomatedTestingPanel 
                schedule={schedule}
                onUpdateSchedule={refetchSchedule}
              /> */}
              
              <SensorStatusPanel 
                sensorStatus={sensorStatus}
              />
              
              <AlertConfigPanel 
                schedule={schedule}
                onUpdateSchedule={refetchSchedule}
              />
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
            <VitalsChart patient={selectedPatient} />
            
            <div className="space-y-6">
              <ModelPredictionPanel patient={selectedPatient} />
              <ManualEntryPanel onSubmit={refetchPatients} />
            </div>
          </div>
        </div>

        <footer className="bg-card border-t border-border px-6 py-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center space-x-6">
              <span>System Status: <span className="text-success font-medium">Operational</span></span>
              <span>Connected Sensors: <span className="font-medium">{sensorStatus.filter(s => s.status === 'online').length}/{sensorStatus.length}</span></span>
              <span>Active Tests: <span className="font-medium">{patients.length}</span></span>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                className="hover:text-card-foreground transition-colors"
                data-testid="button-export-report"
              >
                <i className="fas fa-download mr-1"></i>Export Report
              </button>
              <span className="font-mono">Uptime: {stats?.systemUptime || '0:00:00'}</span>
            </div>
          </div>
        </footer>
      </main>

      <PatientDetailsModal 
        patient={selectedPatient}
        onClose={() => setSelectedPatient(null)}
      />
    </div>
  );
}
