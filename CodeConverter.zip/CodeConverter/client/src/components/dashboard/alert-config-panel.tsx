import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { type TestingSchedule } from '@shared/schema';

interface AlertConfigPanelProps {
  schedule?: TestingSchedule;
  onUpdateSchedule: () => void;
}

export default function AlertConfigPanel({ schedule, onUpdateSchedule }: AlertConfigPanelProps) {
  const queryClient = useQueryClient();
  const [criticalThreshold, setCriticalThreshold] = useState(85);
  const [warningThreshold, setWarningThreshold] = useState(65);
  const [audioAlerts, setAudioAlerts] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);

  useEffect(() => {
    if (schedule) {
      setCriticalThreshold(schedule.criticalThreshold);
      setWarningThreshold(schedule.warningThreshold);
      setAudioAlerts(schedule.audioAlerts);
      setEmailNotifications(schedule.emailNotifications);
      setSmsAlerts(schedule.smsAlerts);
    }
  }, [schedule]);

  const updateConfigMutation = useMutation({
    mutationFn: async (updates: Partial<TestingSchedule>) => {
      await apiRequest('PATCH', '/api/schedule', updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/schedule'] });
      onUpdateSchedule();
    },
  });

  const handleThresholdChange = (type: 'critical' | 'warning', value: number[]) => {
    const newValue = value[0];
    if (type === 'critical') {
      setCriticalThreshold(newValue);
      updateConfigMutation.mutate({ criticalThreshold: newValue });
    } else {
      setWarningThreshold(newValue);
      updateConfigMutation.mutate({ warningThreshold: newValue });
    }
  };

  const handleAlertSettingChange = (setting: string, checked: boolean) => {
    const updates: Partial<TestingSchedule> = { [setting]: checked };
    
    switch (setting) {
      case 'audioAlerts':
        setAudioAlerts(checked);
        break;
      case 'emailNotifications':
        setEmailNotifications(checked);
        break;
      case 'smsAlerts':
        setSmsAlerts(checked);
        break;
    }
    
    updateConfigMutation.mutate(updates);
  };

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold text-card-foreground">Alert Configuration</h3>
      </div>
      
      <div className="p-4 space-y-4">
        <div>
          <label className="text-sm font-medium text-card-foreground mb-2 block">Critical Threshold</label>
          <div className="flex items-center space-x-2">
            <Slider
              value={[criticalThreshold]}
              onValueChange={(value) => handleThresholdChange('critical', value)}
              min={70}
              max={95}
              step={1}
              className="flex-1"
              data-testid="slider-critical-threshold"
            />
            <span className="text-sm font-medium text-card-foreground w-12" data-testid="text-critical-threshold">
              {criticalThreshold}%
            </span>
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-card-foreground mb-2 block">Warning Threshold</label>
          <div className="flex items-center space-x-2">
            <Slider
              value={[warningThreshold]}
              onValueChange={(value) => handleThresholdChange('warning', value)}
              min={50}
              max={80}
              step={1}
              className="flex-1"
              data-testid="slider-warning-threshold"
            />
            <span className="text-sm font-medium text-card-foreground w-12" data-testid="text-warning-threshold">
              {warningThreshold}%
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="audioAlerts"
              checked={audioAlerts}
              onCheckedChange={(checked) => handleAlertSettingChange('audioAlerts', !!checked)}
              data-testid="checkbox-audio-alerts"
            />
            <label htmlFor="audioAlerts" className="text-sm text-card-foreground">
              Audio Alerts
            </label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="emailNotifications"
              checked={emailNotifications}
              onCheckedChange={(checked) => handleAlertSettingChange('emailNotifications', !!checked)}
              data-testid="checkbox-email-notifications"
            />
            <label htmlFor="emailNotifications" className="text-sm text-card-foreground">
              Email Notifications
            </label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="smsAlerts"
              checked={smsAlerts}
              onCheckedChange={(checked) => handleAlertSettingChange('smsAlerts', !!checked)}
              data-testid="checkbox-sms-alerts"
            />
            <label htmlFor="smsAlerts" className="text-sm text-card-foreground">
              SMS Alerts
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
