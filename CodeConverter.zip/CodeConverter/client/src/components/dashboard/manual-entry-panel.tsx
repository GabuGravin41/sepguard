import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Save, Keyboard, Brain, TreePine, Network } from 'lucide-react';
import { insertVitalsSchema } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

interface ManualEntryPanelProps {
  onSubmit: () => void;
}

const manualEntrySchema = insertVitalsSchema.extend({
  patientId: z.string().min(1, 'Patient ID is required'),
  heartRate: z.number().min(30).max(200).optional(),
  temperature: z.number().min(30).max(45).optional(),
  systolicBP: z.number().min(50).max(300).optional(),
  diastolicBP: z.number().min(30).max(200).optional(),
  oxygenSaturation: z.number().min(70).max(100).optional(),
  respiratoryRate: z.number().min(5).max(60).optional(),
}).refine(
  (data) => data.heartRate || data.temperature || data.systolicBP || data.oxygenSaturation,
  {
    message: "At least one vital sign must be provided",
    path: ["heartRate"]
  }
);

type ManualEntryForm = z.infer<typeof manualEntrySchema>;

export default function ManualEntryPanel({ onSubmit }: ManualEntryPanelProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<ManualEntryForm>({
    resolver: zodResolver(manualEntrySchema),
    defaultValues: {
      patientId: '',
      heartRate: undefined,
      temperature: undefined,
      systolicBP: undefined,
      diastolicBP: undefined,
      oxygenSaturation: undefined,
      respiratoryRate: undefined,
      isManual: true,
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (data: ManualEntryForm) => {
      // Calculate mean arterial pressure if systolic and diastolic are provided
      const meanArterialPressure = data.systolicBP && data.diastolicBP ? 
        data.diastolicBP + (data.systolicBP - data.diastolicBP) / 3 : undefined;

      await apiRequest('POST', '/api/vitals', {
        ...data,
        meanArterialPressure,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      form.reset();
      onSubmit();
      toast({
        title: "Vitals Submitted",
        description: "Manual vitals entry saved and sepsis test completed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit vitals",
        variant: "destructive",
      });
    },
  });

  const onFormSubmit = (data: ManualEntryForm) => {
    submitMutation.mutate(data);
  };

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Keyboard size={20} />
          <div>
            <h3 className="font-semibold text-card-foreground">Manual Vitals Entry</h3>
            <p className="text-xs text-muted-foreground">Use when sensors are unavailable</p>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onFormSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="patientId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Patient ID</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter patient ID" 
                      {...field}
                      data-testid="input-patient-id"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="heartRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Heart Rate</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="BPM"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        value={field.value || ''}
                        data-testid="input-heart-rate"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="temperature"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Temperature</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        step="0.1"
                        placeholder="°C"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        value={field.value || ''}
                        data-testid="input-temperature"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="systolicBP"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Systolic BP</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="mmHg"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        value={field.value || ''}
                        data-testid="input-systolic-bp"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="diastolicBP"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Diastolic BP</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="mmHg"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        value={field.value || ''}
                        data-testid="input-diastolic-bp"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="oxygenSaturation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>O2 Saturation</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="%"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        value={field.value || ''}
                        data-testid="input-oxygen-saturation"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="respiratoryRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Respiratory Rate</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="breaths/min"
                        {...field}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        value={field.value || ''}
                        data-testid="input-respiratory-rate"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button 
              type="submit"
              className="w-full"
              disabled={submitMutation.isPending}
              data-testid="button-submit-manual-entry"
            >
              <Save className="mr-2" size={16} />
              {submitMutation.isPending ? 'Submitting...' : 'Submit & Run Test'}
            </Button>
          </form>
        </Form>

      </div>
    </div>
  );
}
