import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { type Alert } from '@shared/schema';

interface AlertsPanelProps {
  alerts: Alert[];
  onAcknowledgeAlert: () => void;
}

export default function AlertsPanel({ alerts, onAcknowledgeAlert }: AlertsPanelProps) {
  const queryClient = useQueryClient();

  const acknowledgeMutation = useMutation({
    mutationFn: async (alertId: string) => {
      await apiRequest('PATCH', `/api/alerts/${alertId}/acknowledge`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
      onAcknowledgeAlert();
    },
  });

  const criticalAlerts = alerts.filter(alert => alert.type === 'critical');
  
  if (criticalAlerts.length === 0) return null;

  return (
    <div className="mb-6">
      {criticalAlerts.map((alert) => (
        <div key={alert.id} className="bg-destructive text-destructive-foreground p-4 rounded-lg alert-pulse mb-4">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="text-xl" />
            <div className="flex-1">
              <h3 className="font-semibold">Critical Alert: High Sepsis Risk Detected</h3>
              <p className="text-sm opacity-90" data-testid={`text-alert-message-${alert.id}`}>
                {alert.message}
              </p>
            </div>
            <Button
              onClick={() => acknowledgeMutation.mutate(alert.id)}
              disabled={acknowledgeMutation.isPending}
              className="bg-destructive-foreground text-destructive hover:bg-opacity-90"
              data-testid={`button-acknowledge-${alert.id}`}
            >
              Acknowledge
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
