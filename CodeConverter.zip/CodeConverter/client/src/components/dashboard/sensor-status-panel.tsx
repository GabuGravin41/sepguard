import { Activity, Thermometer, Heart, Droplets, Keyboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { type SensorStatus } from '@shared/schema';

interface SensorStatusPanelProps {
  sensorStatus: SensorStatus[];
}

export default function SensorStatusPanel({ sensorStatus }: SensorStatusPanelProps) {
  const getSensorIcon = (sensorType: string) => {
    switch (sensorType) {
      case 'heart_rate': return <Heart size={16} />;
      case 'temperature': return <Thermometer size={16} />;
      case 'blood_pressure': return <Activity size={16} />;
      case 'oxygen': return <Droplets size={16} />;
      default: return <Activity size={16} />;
    }
  };

  const getSensorLabel = (sensorType: string) => {
    switch (sensorType) {
      case 'heart_rate': return 'Heart Rate Monitors';
      case 'temperature': return 'Temperature Sensors';
      case 'blood_pressure': return 'Blood Pressure';
      case 'oxygen': return 'O2 Saturation';
      default: return sensorType;
    }
  };

  const getSensorCounts = (sensorType: string) => {
    const sensors = sensorStatus.filter(s => s.sensorType === sensorType);
    const online = sensors.filter(s => s.status === 'online').length;
    const total = sensors.length;
    return { online, total };
  };

  const getStatusClass = (online: number, total: number) => {
    if (total === 0) return 'critical';
    const percentage = online / total;
    if (percentage >= 0.9) return 'normal';
    if (percentage >= 0.7) return 'warning';
    return 'critical';
  };

  const sensorTypes = ['heart_rate', 'temperature', 'blood_pressure', 'oxygen'];

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold text-card-foreground">Sensor Status</h3>
      </div>
      
      <div className="p-4 space-y-3">
        {sensorTypes.map((sensorType) => {
          const { online, total } = getSensorCounts(sensorType);
          const statusClass = getStatusClass(online, total);

          return (
            <div key={sensorType} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`status-indicator status-${statusClass}`}></div>
                <div className="flex items-center space-x-2">
                  {getSensorIcon(sensorType)}
                  <span className="text-sm text-card-foreground">
                    {getSensorLabel(sensorType)}
                  </span>
                </div>
              </div>
              <span 
                className={`text-xs font-medium ${
                  statusClass === 'normal' ? 'text-success' :
                  statusClass === 'warning' ? 'text-warning' :
                  'text-destructive'
                }`}
                data-testid={`text-sensor-count-${sensorType}`}
              >
                {online}/{total}
              </span>
            </div>
          );
        })}

        <div className="pt-3 border-t border-border">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-primary hover:underline"
            data-testid="button-manual-entry-mode"
          >
            <Keyboard className="mr-2" size={16} />
            Manual Entry Mode
          </Button>
        </div>
      </div>
    </div>
  );
}
