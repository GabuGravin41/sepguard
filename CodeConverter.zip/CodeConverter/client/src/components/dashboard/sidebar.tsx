import { Heart, Users, Clock, Bell, Settings, BarChart3 } from 'lucide-react';

interface SidebarProps {
  isDark: boolean;
  onToggleDarkMode: () => void;
  lastUpdate: string;
}

export default function Sidebar({ isDark, onToggleDarkMode, lastUpdate }: SidebarProps) {
  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col shadow-lg">
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Heart className="text-primary-foreground" size={20} />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-card-foreground">SepsisGuard</h1>
            <p className="text-sm text-muted-foreground">Medical Dashboard</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          <li>
            <a 
              href="#" 
              className="flex items-center space-x-3 px-3 py-2 rounded-md bg-primary text-primary-foreground"
              data-testid="nav-dashboard"
            >
              <BarChart3 size={18} />
              <span className="font-medium">Dashboard</span>
            </a>
          </li>
          <li>
            <a 
              href="#" 
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
              data-testid="nav-patients"
            >
              <Users size={18} />
              <span>Patients</span>
            </a>
          </li>
          <li>
            <a 
              href="#" 
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
              data-testid="nav-schedule"
            >
              <Clock size={18} />
              <span>Schedule</span>
            </a>
          </li>
          <li>
            <a 
              href="#" 
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
              data-testid="nav-alerts"
            >
              <Bell size={18} />
              <span>Alerts</span>
              <span className="ml-auto bg-destructive text-destructive-foreground text-xs px-2 py-1 rounded-full">3</span>
            </a>
          </li>
          <li>
            <a 
              href="#" 
              className="flex items-center space-x-3 px-3 py-2 rounded-md text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
              data-testid="nav-settings"
            >
              <Settings size={18} />
              <span>Settings</span>
            </a>
          </li>
        </ul>
      </nav>

      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Night Shift Mode</span>
          <button 
            onClick={onToggleDarkMode}
            className="w-12 h-6 bg-muted rounded-full relative transition-colors"
            data-testid="toggle-dark-mode"
          >
            <div 
              className={`w-5 h-5 bg-background rounded-full absolute top-0.5 transition-transform duration-200 ease-in-out shadow-sm ${
                isDark ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
        <div className="mt-4 text-center">
          <p className="text-xs text-muted-foreground">Last Update</p>
          <p className="text-sm font-mono" data-testid="text-last-update">{lastUpdate}</p>
        </div>
      </div>
    </aside>
  );
}
