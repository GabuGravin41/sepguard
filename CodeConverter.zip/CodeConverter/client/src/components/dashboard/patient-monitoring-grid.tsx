import { Button } from '@/components/ui/button';
import { Filter, Download, Eye, AlertTriangle, UserCheck } from 'lucide-react';
import { type PatientWithVitals } from '@shared/schema';

interface PatientMonitoringGridProps {
  patients: PatientWithVitals[];
  onSelectPatient: (patient: PatientWithVitals) => void;
}

export default function PatientMonitoringGrid({ patients, onSelectPatient }: PatientMonitoringGridProps) {
  const getStatusColor = (riskScore?: number) => {
    if (!riskScore) return 'success';
    if (riskScore >= 85) return 'critical';
    if (riskScore >= 65) return 'warning';
    return 'success';
  };

  const formatTimestamp = (timestamp: string | Date) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffMinutes < 1) return 'Updated now';
    if (diffMinutes < 60) return `Updated ${diffMinutes}m ago`;
    return `Updated ${Math.floor(diffMinutes / 60)}h ago`;
  };

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-semibold text-card-foreground">Patient Monitoring</h3>
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm"
              data-testid="button-filter-patients"
            >
              <Filter className="mr-2" size={16} />
              Filter
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              data-testid="button-export-patients"
            >
              <Download className="mr-2" size={16} />
              Export
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="space-y-4">
          {patients.map((patient) => {
            const riskScore = patient.latestTest?.riskScore || 0;
            const statusColor = getStatusColor(riskScore);
            const vitals = patient.latestVitals;

            return (
              <div 
                key={patient.id}
                className={`border-l-4 ${
                  statusColor === 'critical' ? 'border-destructive bg-destructive/5' :
                  statusColor === 'warning' ? 'border-warning bg-warning/5' :
                  'border-success bg-success/5'
                } p-4 rounded-r-lg`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`status-indicator status-${statusColor}`}></div>
                    <div>
                      <h4 className="font-semibold text-card-foreground" data-testid={`text-patient-name-${patient.id}`}>
                        {patient.name}
                      </h4>
                      <p className="text-sm text-muted-foreground" data-testid={`text-patient-details-${patient.id}`}>
                        {patient.room} • ID: {patient.patientId}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p 
                      className={`text-lg font-bold ${
                        statusColor === 'critical' ? 'text-destructive' :
                        statusColor === 'warning' ? 'text-warning' :
                        'text-success'
                      }`}
                      data-testid={`text-risk-score-${patient.id}`}
                    >
                      {riskScore.toFixed(0)}%
                    </p>
                    <p className="text-xs text-muted-foreground">Risk Score</p>
                  </div>
                </div>
                
                {vitals && (
                  <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">HR</p>
                      <p 
                        className={`font-semibold ${
                          vitals.heartRate && vitals.heartRate > 100 ? 'text-destructive' :
                          vitals.heartRate && vitals.heartRate > 90 ? 'text-warning' :
                          'text-success'
                        }`}
                        data-testid={`text-heart-rate-${patient.id}`}
                      >
                        {vitals.heartRate?.toFixed(0) || '--'}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">Temp</p>
                      <p 
                        className={`font-semibold ${
                          vitals.temperature && (vitals.temperature > 38.5 || vitals.temperature < 36) ? 'text-destructive' :
                          vitals.temperature && vitals.temperature > 37.5 ? 'text-warning' :
                          'text-success'
                        }`}
                        data-testid={`text-temperature-${patient.id}`}
                      >
                        {vitals.temperature?.toFixed(1) || '--'}°C
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">BP</p>
                      <p 
                        className={`font-semibold ${
                          vitals.systolicBP && vitals.systolicBP < 90 ? 'text-destructive' :
                          vitals.systolicBP && vitals.systolicBP < 100 ? 'text-warning' :
                          'text-success'
                        }`}
                        data-testid={`text-blood-pressure-${patient.id}`}
                      >
                        {vitals.systolicBP && vitals.diastolicBP ? 
                          `${vitals.systolicBP.toFixed(0)}/${vitals.diastolicBP.toFixed(0)}` : 
                          '--/--'
                        }
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground">O2</p>
                      <p 
                        className={`font-semibold ${
                          vitals.oxygenSaturation && vitals.oxygenSaturation < 90 ? 'text-destructive' :
                          vitals.oxygenSaturation && vitals.oxygenSaturation < 95 ? 'text-warning' :
                          'text-success'
                        }`}
                        data-testid={`text-oxygen-sat-${patient.id}`}
                      >
                        {vitals.oxygenSaturation?.toFixed(0) || '--'}%
                      </p>
                    </div>
                  </div>
                )}

                <div className="mt-4 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground" data-testid={`text-last-update-${patient.id}`}>
                    {vitals ? formatTimestamp(vitals.timestamp) : 'No data'}
                  </span>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      onClick={() => onSelectPatient(patient)}
                      data-testid={`button-view-details-${patient.id}`}
                    >
                      <Eye className="mr-1" size={14} />
                      View Details
                    </Button>
                    {statusColor === 'critical' && (
                      <Button
                        size="sm"
                        variant="destructive"
                        data-testid={`button-escalate-${patient.id}`}
                      >
                        <AlertTriangle className="mr-1" size={14} />
                        Escalate
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {patients.length > 3 && (
            <div className="border border-dashed border-border p-4 rounded-lg text-center text-muted-foreground">
              <UserCheck className="mx-auto mb-2" size={32} />
              <p className="text-sm">{patients.length - 3} more patients</p>
              <button 
                className="text-xs text-primary hover:underline mt-2"
                data-testid="button-show-all-patients"
              >
                View All
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function formatTimestamp(timestamp: string | Date): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
  
  if (diffMinutes < 1) return 'Updated now';
  if (diffMinutes < 60) return `Updated ${diffMinutes}m ago`;
  return `Updated ${Math.floor(diffMinutes / 60)}h ago`;
}
