import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { RotateCcw, Info, Brain, TreePine, Network } from 'lucide-react';
import { type PatientWithVitals, type SepsisTest } from '@shared/schema';
import { useWebSocket } from '@/hooks/use-websocket';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQueryClient } from '@tanstack/react-query';

interface ModelPredictionPanelProps {
  patient?: PatientWithVitals | null;
}

interface ModelPrediction {
  modelName: string;
  prediction: number;
  confidence: number;
}

export default function ModelPredictionPanel({ patient }: ModelPredictionPanelProps) {
  const queryClient = useQueryClient();

  const { data: testHistory = [] } = useQuery<SepsisTest[]>({
    queryKey: ['/api/patients', patient?.patientId, 'tests'],
    enabled: !!patient?.patientId,
  });

  const retestMutation = useMutation({
    mutationFn: async (patientId: string) => {
      await apiRequest('POST', '/api/test/manual', { patientId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients'] });
      queryClient.invalidateQueries({ queryKey: ['/api/patients', patient?.patientId, 'tests'] });
    },
  });

  const getModelIcon = (modelName: string) => {
    if (modelName.includes('Logistic')) return <Brain size={20} />;
    if (modelName.includes('Forest')) return <TreePine size={20} />;
    if (modelName.includes('Neural')) return <Network size={20} />;
    return <Brain size={20} />;
  };

  const getModelColor = (prediction: number) => {
    if (prediction >= 85) return 'destructive';
    if (prediction >= 65) return 'warning';
    return 'success';
  };

  if (!patient) {
    return (
      <div className="bg-card rounded-lg border border-border shadow-sm">
        <div className="p-4 border-b border-border">
          <h3 className="font-semibold text-card-foreground">AI Model Predictions</h3>
        </div>
        <div className="p-4 h-64 flex items-center justify-center text-muted-foreground">
          <div className="text-center">
            <Brain size={48} className="mx-auto mb-4" />
            <p>Select a patient to view model predictions</p>
          </div>
        </div>
      </div>
    );
  }

  const latestTest = patient.latestTest || testHistory[0];
  let modelPredictions: ModelPrediction[] = [];
  
  if (latestTest?.modelPredictions) {
    try {
      modelPredictions = JSON.parse(latestTest.modelPredictions);
    } catch (e) {
      console.error('Error parsing model predictions:', e);
    }
  }

  const ensemblePrediction = latestTest?.confidence || 0;

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold text-card-foreground">AI Model Predictions</h3>
      </div>
      
      <div className="p-4 space-y-4">
        {modelPredictions.length > 0 ? (
          <div className="space-y-3">
            {modelPredictions.map((model, index) => {
              const color = getModelColor(model.prediction);
              return (
                <div 
                  key={index}
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    color === 'destructive' ? 'bg-destructive/10 border-destructive/20' :
                    color === 'warning' ? 'bg-warning/10 border-warning/20' :
                    'bg-success/10 border-success/20'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    {getModelIcon(model.modelName)}
                    <div>
                      <p className="font-medium text-card-foreground" data-testid={`text-model-name-${index}`}>
                        {model.modelName}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {index === 0 ? 'Primary Model' : index === 1 ? 'Secondary Model' : 'Validation Model'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p 
                      className={`text-xl font-bold ${
                        color === 'destructive' ? 'text-destructive' :
                        color === 'warning' ? 'text-warning' :
                        'text-success'
                      }`}
                      data-testid={`text-model-prediction-${index}`}
                    >
                      {model.prediction.toFixed(0)}%
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Confidence: {(model.confidence * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center text-muted-foreground py-8">
            <Brain size={48} className="mx-auto mb-4" />
            <p>No predictions available</p>
            <p className="text-xs">Run a test to generate predictions</p>
          </div>
        )}

        {latestTest && (
          <div className="pt-3 border-t border-border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-card-foreground">Ensemble Prediction</span>
              <span 
                className={`text-sm font-bold ${
                  ensemblePrediction >= 85 ? 'text-destructive' :
                  ensemblePrediction >= 65 ? 'text-warning' :
                  'text-success'
                }`}
                data-testid="text-ensemble-prediction"
              >
                {ensemblePrediction.toFixed(0)}%
              </span>
            </div>
            <Progress 
              value={ensemblePrediction} 
              className="w-full h-3"
              data-testid="progress-ensemble-prediction"
            />
            <p className="text-xs text-muted-foreground mt-1">
              {ensemblePrediction >= 85 ? 'High sepsis risk detected' :
               ensemblePrediction >= 65 ? 'Moderate sepsis risk' :
               'Low sepsis risk'}
            </p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={() => patient.patientId && retestMutation.mutate(patient.patientId)}
            disabled={retestMutation.isPending}
            data-testid="button-retest-patient"
          >
            <RotateCcw className="mr-2" size={16} />
            {retestMutation.isPending ? 'Testing...' : 'Retest'}
          </Button>
          <Button
            variant="secondary"
            data-testid="button-view-model-details"
          >
            <Info className="mr-2" size={16} />
            Details
          </Button>
        </div>
      </div>
    </div>
  );
}
