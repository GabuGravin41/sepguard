import { UserCheck, AlertTriangle, FlaskConical, Timer, TrendingUp, TrendingDown } from 'lucide-react';

interface StatsOverviewProps {
  stats?: {
    activePatients: number;
    highRiskCount: number;
    criticalCount: number;
    testsToday: number;
    avgResponseTime: string;
    systemUptime: string;
  };
}

export default function StatsOverview({ stats }: StatsOverviewProps) {
  if (!stats) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm font-medium">Active Patients</p>
            <p className="text-3xl font-bold text-card-foreground" data-testid="stat-active-patients">
              {stats.activePatients}
            </p>
          </div>
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <UserCheck className="text-primary" size={24} />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <TrendingUp className="text-success" size={16} />
          <span className="text-success ml-1">3</span>
          <span className="text-muted-foreground ml-1">from yesterday</span>
        </div>
      </div>

      <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm font-medium">High Risk</p>
            <p className="text-3xl font-bold text-warning" data-testid="stat-high-risk">
              {stats.highRiskCount}
            </p>
          </div>
          <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
            <AlertTriangle className="text-warning" size={24} />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <TrendingUp className="text-warning" size={16} />
          <span className="text-warning ml-1">1</span>
          <span className="text-muted-foreground ml-1">since last hour</span>
        </div>
      </div>

      <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm font-medium">Tests Today</p>
            <p className="text-3xl font-bold text-card-foreground" data-testid="stat-tests-today">
              {stats.testsToday}
            </p>
          </div>
          <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
            <FlaskConical className="text-success" size={24} />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <span className="text-success">✓ 98.7%</span>
          <span className="text-muted-foreground ml-1">accuracy rate</span>
        </div>
      </div>

      <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm font-medium">Avg Response</p>
            <p className="text-3xl font-bold text-card-foreground" data-testid="stat-avg-response">
              {stats.avgResponseTime}
            </p>
          </div>
          <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
            <Timer className="text-muted-foreground" size={24} />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <TrendingDown className="text-success" size={16} />
          <span className="text-success ml-1">15s</span>
          <span className="text-muted-foreground ml-1">improvement</span>
        </div>
      </div>
    </div>
  );
}
