import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Printer, UserCheck, X, AlertTriangle, Clock, Activity } from 'lucide-react';
import { type PatientWithVitals, type SepsisTest, type Alert } from '@shared/schema';

interface PatientDetailsModalProps {
  patient?: PatientWithVitals | null;
  onClose: () => void;
}

export default function PatientDetailsModal({ patient, onClose }: PatientDetailsModalProps) {
  const { data: vitalsHistory = [] } = useQuery({
    queryKey: ['/api/patients', patient?.patientId, 'vitals'],
    enabled: !!patient?.patientId,
  });

  const { data: testHistory = [] } = useQuery<SepsisTest[]>({
    queryKey: ['/api/patients', patient?.patientId, 'tests'],
    enabled: !!patient?.patientId,
  });

  const { data: alertHistory = [] } = useQuery<Alert[]>({
    queryKey: ['/api/alerts'],
    select: (alerts: Alert[]) => alerts.filter((alert: Alert) => alert.patientId === patient?.patientId),
    enabled: !!patient?.patientId,
  });

  const formatTimestamp = (timestamp: string | Date) => {
    return new Date(timestamp).toLocaleString();
  };

  const getRiskLevelColor = (riskScore: number) => {
    if (riskScore >= 85) return 'destructive';
    if (riskScore >= 65) return 'warning';
    if (riskScore >= 40) return 'default';
    return 'success';
  };

  const getRiskLevelText = (riskScore: number) => {
    if (riskScore >= 85) return 'Critical';
    if (riskScore >= 65) return 'High';
    if (riskScore >= 40) return 'Moderate';
    return 'Low';
  };

  const getRecommendedActions = (riskScore: number) => {
    if (riskScore >= 85) {
      return [
        "Immediate medical attention required",
        "Contact attending physician",
        "Consider antibiotic therapy",
        "Increase monitoring frequency"
      ];
    } else if (riskScore >= 65) {
      return [
        "Monitor closely",
        "Consider additional testing",
        "Notify medical team"
      ];
    } else if (riskScore >= 40) {
      return [
        "Continue routine monitoring",
        "Review patient history"
      ];
    }
    return ["Maintain current care plan"];
  };

  if (!patient) return null;

  return (
    <Dialog open={!!patient} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div>
              <span data-testid="text-modal-patient-name">{patient.name} - Detailed View</span>
              <p className="text-muted-foreground text-sm font-normal mt-1" data-testid="text-modal-patient-details">
                {patient.room} • Age: {patient.age} • {patient.gender === 0 ? 'Female' : 'Male'}
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[70vh]">
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Patient Information */}
              <div className="space-y-4">
                <h3 className="font-semibold text-card-foreground border-b border-border pb-2">
                  Patient Information
                </h3>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Age</p>
                    <p className="font-semibold" data-testid="text-patient-age">
                      {patient.age} years
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Gender</p>
                    <p className="font-semibold" data-testid="text-patient-gender">
                      {patient.gender === 0 ? 'Female' : 'Male'}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Episode Number</p>
                    <p className="font-semibold" data-testid="text-patient-episode">
                      {patient.episodeNumber}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Admission Date</p>
                    <p className="font-semibold" data-testid="text-patient-admission">
                      {new Date(patient.admissionDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {patient.latestVitals && (
                  <div className="pt-4">
                    <h4 className="font-medium text-card-foreground mb-3">Current Vitals</h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-muted/50 p-3 rounded">
                        <p className="text-muted-foreground">Heart Rate</p>
                        <p 
                          className={`text-lg font-bold ${
                            patient.latestVitals.heartRate && patient.latestVitals.heartRate > 100 ? 'text-destructive' : 'text-success'
                          }`}
                          data-testid="text-modal-heart-rate"
                        >
                          {patient.latestVitals.heartRate?.toFixed(0) || '--'} BPM
                        </p>
                      </div>
                      <div className="bg-muted/50 p-3 rounded">
                        <p className="text-muted-foreground">Temperature</p>
                        <p 
                          className={`text-lg font-bold ${
                            patient.latestVitals.temperature && (patient.latestVitals.temperature > 38.5 || patient.latestVitals.temperature < 36) ? 'text-destructive' :
                            patient.latestVitals.temperature && patient.latestVitals.temperature > 37.5 ? 'text-warning' : 'text-success'
                          }`}
                          data-testid="text-modal-temperature"
                        >
                          {patient.latestVitals.temperature?.toFixed(1) || '--'}°C
                        </p>
                      </div>
                      <div className="bg-muted/50 p-3 rounded">
                        <p className="text-muted-foreground">Blood Pressure</p>
                        <p 
                          className={`text-lg font-bold ${
                            patient.latestVitals.systolicBP && patient.latestVitals.systolicBP < 90 ? 'text-destructive' : 'text-success'
                          }`}
                          data-testid="text-modal-blood-pressure"
                        >
                          {patient.latestVitals.systolicBP && patient.latestVitals.diastolicBP ? 
                            `${patient.latestVitals.systolicBP.toFixed(0)}/${patient.latestVitals.diastolicBP.toFixed(0)} mmHg` : 
                            '--/-- mmHg'
                          }
                        </p>
                      </div>
                      <div className="bg-muted/50 p-3 rounded">
                        <p className="text-muted-foreground">O2 Saturation</p>
                        <p 
                          className={`text-lg font-bold ${
                            patient.latestVitals.oxygenSaturation && patient.latestVitals.oxygenSaturation < 90 ? 'text-destructive' :
                            patient.latestVitals.oxygenSaturation && patient.latestVitals.oxygenSaturation < 95 ? 'text-warning' : 'text-success'
                          }`}
                          data-testid="text-modal-oxygen-saturation"
                        >
                          {patient.latestVitals.oxygenSaturation?.toFixed(0) || '--'}%
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Risk Assessment & Timeline */}
              <div className="space-y-4">
                <h3 className="font-semibold text-card-foreground border-b border-border pb-2">
                  Risk Assessment Timeline
                </h3>
                
                <div className="space-y-3">
                  {testHistory.slice(0, 6).map((test: SepsisTest, index: number) => {
                    const riskLevel = getRiskLevelText(test.riskScore);
                    const color = getRiskLevelColor(test.riskScore);
                    
                    return (
                      <div 
                        key={test.id}
                        className={`flex items-center space-x-3 p-3 rounded border-l-4 ${
                          color === 'destructive' ? 'bg-destructive/10 border-destructive' :
                          color === 'warning' ? 'bg-warning/10 border-warning' :
                          'bg-success/10 border-success'
                        }`}
                      >
                        <div className="text-xs text-muted-foreground w-16">
                          {new Date(test.timestamp).toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <p className="text-sm font-medium text-card-foreground">
                              {riskLevel} Risk: {test.riskScore.toFixed(0)}%
                            </p>
                            <Badge 
                              variant={color === 'destructive' ? 'destructive' : color === 'warning' ? 'secondary' : 'default'}
                              data-testid={`badge-risk-level-${index}`}
                            >
                              {riskLevel}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {test.isAutomatic ? 'Automated test' : 'Manual test'}
                          </p>
                        </div>
                      </div>
                    );
                  })}

                  {testHistory.length === 0 && (
                    <div className="text-center text-muted-foreground py-8">
                      <Activity size={32} className="mx-auto mb-2" />
                      <p className="text-sm">No test history available</p>
                    </div>
                  )}
                </div>

                {patient.latestTest && (
                  <div className="pt-4">
                    <h4 className="font-medium text-card-foreground mb-3">Recommended Actions</h4>
                    <div className="space-y-2 text-sm">
                      {getRecommendedActions(patient.latestTest.riskScore).map((action, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <div 
                            className={`w-2 h-2 rounded-full ${
                              patient.latestTest!.riskScore >= 85 ? 'bg-destructive' :
                              patient.latestTest!.riskScore >= 65 ? 'bg-warning' :
                              'bg-success'
                            }`}
                          />
                          <span data-testid={`text-recommendation-${index}`}>{action}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Alert History */}
            {alertHistory.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-semibold text-card-foreground border-b border-border pb-2">
                  Alert History
                </h3>
                <div className="space-y-2">
                  {alertHistory.slice(0, 5).map((alert: Alert, index: number) => (
                    <div 
                      key={alert.id}
                      className={`flex items-start space-x-3 p-3 rounded border-l-4 ${
                        alert.type === 'critical' ? 'bg-destructive/10 border-destructive' :
                        alert.type === 'warning' ? 'bg-warning/10 border-warning' :
                        'bg-muted/50 border-border'
                      }`}
                    >
                      <AlertTriangle 
                        size={16} 
                        className={`mt-0.5 ${
                          alert.type === 'critical' ? 'text-destructive' :
                          alert.type === 'warning' ? 'text-warning' :
                          'text-muted-foreground'
                        }`}
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-card-foreground" data-testid={`text-alert-message-${index}`}>
                          {alert.message}
                        </p>
                        <div className="flex items-center space-x-2 mt-1">
                          <p className="text-xs text-muted-foreground">
                            {formatTimestamp(alert.timestamp)}
                          </p>
                          {alert.acknowledged && (
                            <Badge variant="outline" className="text-xs">
                              Acknowledged
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Separator />

            <div className="flex justify-end space-x-3">
              <Button 
                variant="secondary"
                data-testid="button-print-report"
              >
                <Printer className="mr-2" size={16} />
                Printer Report
              </Button>
              <Button 
                data-testid="button-escalate-to-doctor"
              >
                <UserCheck className="mr-2" size={16} />
                Escalate to Doctor
              </Button>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

function formatTimestamp(timestamp: string | Date): string {
  return new Date(timestamp).toLocaleString();
}
