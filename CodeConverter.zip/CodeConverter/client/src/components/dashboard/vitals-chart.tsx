import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Activity, TrendingUp, TrendingDown } from 'lucide-react';
import { type PatientWithVitals, type Vitals } from '@shared/schema';
import { useState } from 'react';

interface VitalsChartProps {
  patient?: PatientWithVitals | null;
}

export default function VitalsChart({ patient }: VitalsChartProps) {
  const [timeRange, setTimeRange] = useState('24');

  const { data: vitalsHistory = [] } = useQuery<Vitals[]>({
    queryKey: ['/api/patients', patient?.patientId, 'vitals'],
    enabled: !!patient?.patientId,
  });

  const formatChartData = () => {
    if (!vitalsHistory.length) return [];

    const hoursAgo = parseInt(timeRange);
    const cutoffTime = new Date(Date.now() - hoursAgo * 60 * 60 * 1000);
    
    return vitalsHistory
      .filter((v: Vitals) => new Date(v.timestamp) >= cutoffTime)
      .map((vitals: Vitals) => ({
        time: new Date(vitals.timestamp).toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        heartRate: vitals.heartRate,
        temperature: vitals.temperature,
        systolicBP: vitals.systolicBP,
        oxygenSat: vitals.oxygenSaturation,
      }))
      .reverse();
  };

  const getTrend = (current?: number | null, previous?: number | null) => {
    if (!current || !previous) return null;
    return current > previous ? 'up' : 'down';
  };

  const chartData = formatChartData();
  const currentVitals = patient?.latestVitals;
  const previousVitals = vitalsHistory[1];

  if (!patient) {
    return (
      <div className="bg-card rounded-lg border border-border shadow-sm">
        <div className="p-4 border-b border-border">
          <h3 className="font-semibold text-card-foreground">Vitals Timeline</h3>
        </div>
        <div className="p-4 h-64 flex items-center justify-center text-muted-foreground">
          <div className="text-center">
            <Activity size={48} className="mx-auto mb-4" />
            <p>Select a patient to view vitals timeline</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-card-foreground">
            Vitals Timeline - {patient.name}
          </h3>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32" data-testid="select-time-range">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2">Last 2 hours</SelectItem>
              <SelectItem value="6">Last 6 hours</SelectItem>
              <SelectItem value="12">Last 12 hours</SelectItem>
              <SelectItem value="24">Last 24 hours</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="p-4">
        {chartData.length > 0 ? (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="heartRate" 
                  stroke="hsl(var(--destructive))" 
                  strokeWidth={2}
                  name="Heart Rate"
                />
                <Line 
                  type="monotone" 
                  dataKey="temperature" 
                  stroke="hsl(var(--warning))" 
                  strokeWidth={2}
                  name="Temperature"
                />
                <Line 
                  type="monotone" 
                  dataKey="systolicBP" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  name="Systolic BP"
                />
                <Line 
                  type="monotone" 
                  dataKey="oxygenSat" 
                  stroke="hsl(var(--success))" 
                  strokeWidth={2}
                  name="O2 Saturation"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <Activity size={48} className="mx-auto mb-4" />
              <p>No vitals data available</p>
            </div>
          </div>
        )}

        <div className="mt-4 grid grid-cols-4 gap-4 text-center">
          <div>
            <p className="text-xs text-muted-foreground">Current HR</p>
            <p 
              className={`text-lg font-bold ${
                currentVitals?.heartRate && currentVitals.heartRate > 100 ? 'text-destructive' : 'text-success'
              }`}
              data-testid="text-current-hr"
            >
              {currentVitals?.heartRate?.toFixed(0) || '--'}
            </p>
            {getTrend(currentVitals?.heartRate, previousVitals?.heartRate) && (
              <p className={`text-xs ${getTrend(currentVitals?.heartRate, previousVitals?.heartRate) === 'up' ? 'text-destructive' : 'text-success'}`}>
                {getTrend(currentVitals?.heartRate, previousVitals?.heartRate) === 'up' ? 
                  <TrendingUp className="inline" size={12} /> : 
                  <TrendingDown className="inline" size={12} />
                } from {previousVitals?.heartRate?.toFixed(0)}
              </p>
            )}
          </div>
          
          <div>
            <p className="text-xs text-muted-foreground">Current Temp</p>
            <p 
              className={`text-lg font-bold ${
                currentVitals?.temperature && (currentVitals.temperature > 38.5 || currentVitals.temperature < 36) ? 'text-destructive' :
                currentVitals?.temperature && currentVitals.temperature > 37.5 ? 'text-warning' : 'text-success'
              }`}
              data-testid="text-current-temp"
            >
              {currentVitals?.temperature?.toFixed(1) || '--'}°C
            </p>
            {getTrend(currentVitals?.temperature, previousVitals?.temperature) && (
              <p className={`text-xs ${getTrend(currentVitals?.temperature, previousVitals?.temperature) === 'up' ? 'text-warning' : 'text-success'}`}>
                {getTrend(currentVitals?.temperature, previousVitals?.temperature) === 'up' ? 
                  <TrendingUp className="inline" size={12} /> : 
                  <TrendingDown className="inline" size={12} />
                } from {previousVitals?.temperature?.toFixed(1)}°C
              </p>
            )}
          </div>
          
          <div>
            <p className="text-xs text-muted-foreground">Current BP</p>
            <p 
              className={`text-lg font-bold ${
                currentVitals?.systolicBP && currentVitals.systolicBP < 90 ? 'text-destructive' : 'text-success'
              }`}
              data-testid="text-current-bp"
            >
              {currentVitals?.systolicBP && currentVitals?.diastolicBP ? 
                `${currentVitals.systolicBP.toFixed(0)}/${currentVitals.diastolicBP.toFixed(0)}` : 
                '--/--'
              }
            </p>
            {getTrend(currentVitals?.systolicBP, previousVitals?.systolicBP) && (
              <p className={`text-xs ${getTrend(currentVitals?.systolicBP, previousVitals?.systolicBP) === 'down' ? 'text-warning' : 'text-success'}`}>
                {getTrend(currentVitals?.systolicBP, previousVitals?.systolicBP) === 'up' ? 
                  <TrendingUp className="inline" size={12} /> : 
                  <TrendingDown className="inline" size={12} />
                } from {previousVitals?.systolicBP?.toFixed(0)}/{previousVitals?.diastolicBP?.toFixed(0)}
              </p>
            )}
          </div>
          
          <div>
            <p className="text-xs text-muted-foreground">Current O2</p>
            <p 
              className={`text-lg font-bold ${
                currentVitals?.oxygenSaturation && currentVitals.oxygenSaturation < 90 ? 'text-destructive' :
                currentVitals?.oxygenSaturation && currentVitals.oxygenSaturation < 95 ? 'text-warning' : 'text-success'
              }`}
              data-testid="text-current-o2"
            >
              {currentVitals?.oxygenSaturation?.toFixed(0) || '--'}%
            </p>
            {getTrend(currentVitals?.oxygenSaturation, previousVitals?.oxygenSaturation) && (
              <p className={`text-xs ${getTrend(currentVitals?.oxygenSaturation, previousVitals?.oxygenSaturation) === 'down' ? 'text-warning' : 'text-success'}`}>
                {getTrend(currentVitals?.oxygenSaturation, previousVitals?.oxygenSaturation) === 'up' ? 
                  <TrendingUp className="inline" size={12} /> : 
                  <TrendingDown className="inline" size={12} />
                } from {previousVitals?.oxygenSaturation?.toFixed(0)}%
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
