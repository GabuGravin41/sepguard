import { Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  currentTime: string;
}

export default function Header({ currentTime }: HeaderProps) {
  return (
    <header className="bg-card border-b border-border px-6 py-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-card-foreground">Patient Monitoring Dashboard</h2>
          <p className="text-muted-foreground">Real-time sepsis detection and monitoring</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <div className="status-indicator status-normal sensor-status"></div>
            <span>Auto-refresh: ON</span>
          </div>
          
          <div className="text-sm font-mono bg-muted px-3 py-1 rounded-md">
            <span data-testid="text-current-time">{currentTime}</span>
          </div>
          
          <Button 
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            data-testid="button-emergency"
          >
            <Phone className="mr-2" size={16} />
            Emergency
          </Button>
        </div>
      </div>
    </header>
  );
}
