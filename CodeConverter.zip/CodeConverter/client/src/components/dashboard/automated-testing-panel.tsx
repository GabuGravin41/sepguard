import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Play, CheckCircle } from 'lucide-react';
import { type TestingSchedule } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

interface AutomatedTestingPanelProps {
  schedule?: TestingSchedule;
  onUpdateSchedule: () => void;
}

export default function AutomatedTestingPanel({ schedule, onUpdateSchedule }: AutomatedTestingPanelProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedInterval, setSelectedInterval] = useState<string>(
    schedule ? schedule.intervalMinutes.toString() : '120'
  );

  const updateScheduleMutation = useMutation({
    mutationFn: async (intervalMinutes: number) => {
      await apiRequest('PATCH', '/api/schedule', { intervalMinutes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/schedule'] });
      onUpdateSchedule();
      toast({
        title: "Testing schedule updated",
        description: `Automated tests will now run every ${selectedInterval} minutes`,
      });
    },
  });

  const runManualTestMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/test/manual', {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Manual test initiated",
        description: "Running sepsis screening for all patients",
      });
    },
  });

  const getNextTestTime = () => {
    if (!schedule?.nextRun) return 'Unknown';
    const now = new Date();
    const nextRun = new Date(schedule.nextRun);
    const diffMinutes = Math.floor((nextRun.getTime() - now.getTime()) / (1000 * 60));
    
    if (diffMinutes <= 0) return 'Starting soon...';
    if (diffMinutes < 60) return `${diffMinutes} minutes`;
    return `${Math.floor(diffMinutes / 60)}h ${diffMinutes % 60}m`;
  };

  const getTestProgress = () => {
    if (!schedule?.lastRun || !schedule?.nextRun) return 0;
    const lastRun = new Date(schedule.lastRun);
    const nextRun = new Date(schedule.nextRun);
    const now = new Date();
    
    const totalInterval = nextRun.getTime() - lastRun.getTime();
    const elapsed = now.getTime() - lastRun.getTime();
    
    return Math.min(100, Math.max(0, (elapsed / totalInterval) * 100));
  };

  const handleIntervalChange = (value: string) => {
    setSelectedInterval(value);
    updateScheduleMutation.mutate(parseInt(value));
  };

  const getIntervalLabel = (minutes: number) => {
    if (minutes < 60) return `Every ${minutes} minutes`;
    if (minutes === 60) return 'Every 1 hour';
    return `Every ${minutes / 60} hours`;
  };

  return (
    <div className="bg-card rounded-lg border border-border shadow-sm">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-card-foreground">Automated Testing</h3>
          <div className="flex items-center space-x-2">
            <div className="status-indicator status-normal sensor-status"></div>
            <span className="text-xs text-success font-medium" data-testid="text-testing-status">
              {schedule?.isActive ? 'Running' : 'Stopped'}
            </span>
          </div>
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">Test Interval</span>
            <span className="text-sm font-medium text-card-foreground" data-testid="text-test-interval">
              {schedule ? getIntervalLabel(schedule.intervalMinutes) : 'Loading...'}
            </span>
          </div>
          <Progress 
            value={getTestProgress()} 
            className="w-full h-2"
            data-testid="progress-test-interval"
          />
          <p className="text-xs text-muted-foreground mt-1" data-testid="text-next-test">
            Next test in {getNextTestTime()}
          </p>
        </div>

        <div>
          <label className="text-sm font-medium text-card-foreground mb-2 block">Testing Schedule</label>
          <Select 
            value={selectedInterval} 
            onValueChange={handleIntervalChange}
            disabled={updateScheduleMutation.isPending}
          >
            <SelectTrigger data-testid="select-testing-schedule">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="15">Every 15 minutes</SelectItem>
              <SelectItem value="30">Every 30 minutes</SelectItem>
              <SelectItem value="60">Every 1 hour</SelectItem>
              <SelectItem value="120">Every 2 hours</SelectItem>
              <SelectItem value="240">Every 4 hours</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <h4 className="text-sm font-medium text-card-foreground">Recent Tests</h4>
          <div className="space-y-1">
            <div className="flex justify-between items-center text-xs">
              <span className="text-muted-foreground">14:30</span>
              <span className="text-success">
                <CheckCircle className="inline mr-1" size={12} />
                Completed ({patients.length} patients)
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-muted-foreground">12:30</span>
              <span className="text-success">
                <CheckCircle className="inline mr-1" size={12} />
                Completed ({patients.length} patients)
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-muted-foreground">10:30</span>
              <span className="text-success">
                <CheckCircle className="inline mr-1" size={12} />
                Completed ({Math.max(0, patients.length - 1)} patients)
              </span>
            </div>
          </div>
        </div>

        <Button 
          className="w-full" 
          onClick={() => runManualTestMutation.mutate()}
          disabled={runManualTestMutation.isPending}
          data-testid="button-run-manual-test"
        >
          <Play className="mr-2" size={16} />
          {runManualTestMutation.isPending ? 'Running Test...' : 'Run Manual Test'}
        </Button>
      </div>
    </div>
  );
}
