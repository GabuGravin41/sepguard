import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const patients = pgTable("patients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  patientId: text("patient_id").notNull().unique(),
  room: text("room").notNull(),
  age: integer("age").notNull(),
  gender: integer("gender").notNull(), // 0: female, 1: male
  episodeNumber: integer("episode_number").notNull().default(1),
  admissionDate: timestamp("admission_date").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const vitals = pgTable("vitals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: text("patient_id").notNull(),
  heartRate: real("heart_rate"),
  temperature: real("temperature"),
  systolicBP: real("systolic_bp"),
  diastolicBP: real("diastolic_bp"),
  meanArterialPressure: real("mean_arterial_pressure"),
  oxygenSaturation: real("oxygen_saturation"),
  respiratoryRate: real("respiratory_rate"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  isManual: boolean("is_manual").notNull().default(false),
});

export const sepsisTests = pgTable("sepsis_tests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: text("patient_id").notNull(),
  riskScore: real("risk_score").notNull(),
  modelPredictions: text("model_predictions").notNull(), // JSON string
  confidence: real("confidence").notNull(),
  isAutomatic: boolean("is_automatic").notNull().default(true),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: text("patient_id").notNull(),
  type: text("type").notNull(), // "critical", "warning", "info"
  message: text("message").notNull(),
  acknowledged: boolean("acknowledged").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const sensorStatus = pgTable("sensor_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sensorType: text("sensor_type").notNull(), // "heart_rate", "temperature", "blood_pressure", "oxygen"
  patientId: text("patient_id").notNull(),
  status: text("status").notNull(), // "online", "offline", "warning"
  lastUpdate: timestamp("last_update").notNull().defaultNow(),
});

export const testingSchedule = pgTable("testing_schedule", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  intervalMinutes: integer("interval_minutes").notNull().default(120),
  isActive: boolean("is_active").notNull().default(true),
  lastRun: timestamp("last_run"),
  nextRun: timestamp("next_run"),
  criticalThreshold: real("critical_threshold").notNull().default(85),
  warningThreshold: real("warning_threshold").notNull().default(65),
  audioAlerts: boolean("audio_alerts").notNull().default(true),
  emailNotifications: boolean("email_notifications").notNull().default(true),
  smsAlerts: boolean("sms_alerts").notNull().default(false),
});

// Insert schemas
export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
  createdAt: true,
});

export const insertVitalsSchema = createInsertSchema(vitals).omit({
  id: true,
  timestamp: true,
});

export const insertSepsisTestSchema = createInsertSchema(sepsisTests).omit({
  id: true,
  timestamp: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  timestamp: true,
});

export const insertSensorStatusSchema = createInsertSchema(sensorStatus).omit({
  id: true,
  lastUpdate: true,
});

export const insertTestingScheduleSchema = createInsertSchema(testingSchedule).omit({
  id: true,
});

// Types
export type Patient = typeof patients.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;

export type Vitals = typeof vitals.$inferSelect;
export type InsertVitals = z.infer<typeof insertVitalsSchema>;

export type SepsisTest = typeof sepsisTests.$inferSelect;
export type InsertSepsisTest = z.infer<typeof insertSepsisTestSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type SensorStatus = typeof sensorStatus.$inferSelect;
export type InsertSensorStatus = z.infer<typeof insertSensorStatusSchema>;

export type TestingSchedule = typeof testingSchedule.$inferSelect;
export type InsertTestingSchedule = z.infer<typeof insertTestingScheduleSchema>;

// Additional types for frontend
export type PatientWithVitals = Patient & {
  latestVitals?: Vitals;
  latestTest?: SepsisTest;
  alertCount?: number;
};

export type ModelPrediction = {
  modelName: string;
  prediction: number;
  confidence: number;
};

export type SepsisRiskAssessment = {
  riskScore: number;
  riskLevel: "low" | "moderate" | "high" | "critical";
  modelPredictions: ModelPrediction[];
  ensemblePrediction: number;
  recommendedActions: string[];
};
