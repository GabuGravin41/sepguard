import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertVitalsSchema, insertPatientSchema, insertAlertSchema } from "@shared/schema";
import { sepsisScheduler } from "./services/sepsis-scheduler";
import { sensorSimulator } from "./services/sensor-simulator";
import { calculateSepsisRisk } from "./services/sepsis-prediction";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to WebSocket');
    
    // Add client to both scheduler and sensor simulator
    sepsisScheduler.addWebSocketClient(ws);
    sensorSimulator.addWebSocketClient(ws);

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'run_manual_test':
            if (data.patientId) {
              const result = await sepsisScheduler.runManualTest(data.patientId);
              ws.send(JSON.stringify({
                type: 'manual_test_result',
                patientId: data.patientId,
                result,
              }));
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  // Start services
  await sepsisScheduler.startScheduler();
  sensorSimulator.startSimulation();

  // API Routes

  // Get all patients with latest vitals and test results
  app.get("/api/patients", async (req, res) => {
    try {
      const patients = await storage.getPatients();
      res.json(patients);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch patients" });
    }
  });

  // Get specific patient details
  app.get("/api/patients/:id", async (req, res) => {
    try {
      const patient = await storage.getPatient(req.params.id);
      if (!patient) {
        return res.status(404).json({ error: "Patient not found" });
      }
      res.json(patient);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch patient" });
    }
  });

  // Create new patient
  app.post("/api/patients", async (req, res) => {
    try {
      const validatedData = insertPatientSchema.parse(req.body);
      const patient = await storage.createPatient(validatedData);
      res.status(201).json(patient);
    } catch (error) {
      res.status(400).json({ error: "Invalid patient data" });
    }
  });

  // Add manual vitals entry
  app.post("/api/vitals", async (req, res) => {
    try {
      const validatedData = insertVitalsSchema.parse(req.body);
      
      // Calculate mean arterial pressure if not provided
      if (!validatedData.meanArterialPressure && validatedData.systolicBP && validatedData.diastolicBP) {
        validatedData.meanArterialPressure = validatedData.diastolicBP + (validatedData.systolicBP - validatedData.diastolicBP) / 3;
      }

      const vitals = await storage.createVitals(validatedData);
      
      // Run sepsis test automatically after manual entry
      const patient = await storage.getPatientByPatientId(validatedData.patientId);
      if (patient) {
        const riskAssessment = calculateSepsisRisk(vitals, patient);
        
        await storage.createSepsisTest({
          patientId: validatedData.patientId,
          riskScore: riskAssessment.riskScore,
          modelPredictions: JSON.stringify(riskAssessment.modelPredictions),
          confidence: riskAssessment.ensemblePrediction,
          isAutomatic: false,
        });

        // Create alert if risk is high
        const schedule = await storage.getTestingSchedule();
        if (schedule && riskAssessment.riskScore >= schedule.warningThreshold) {
          await storage.createAlert({
            patientId: validatedData.patientId,
            type: riskAssessment.riskScore >= schedule.criticalThreshold ? 'critical' : 'warning',
            message: `Manual test result: ${riskAssessment.riskScore.toFixed(1)}% sepsis risk`,
            acknowledged: false,
          });
        }
      }

      res.status(201).json(vitals);
    } catch (error) {
      res.status(400).json({ error: "Invalid vitals data" });
    }
  });

  // Get patient vitals history
  app.get("/api/patients/:patientId/vitals", async (req, res) => {
    try {
      const vitals = await storage.getVitalsHistory(req.params.patientId);
      res.json(vitals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vitals history" });
    }
  });

  // Get patient sepsis test history
  app.get("/api/patients/:patientId/tests", async (req, res) => {
    try {
      const tests = await storage.getSepsisTestHistory(req.params.patientId);
      res.json(tests);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch test history" });
    }
  });

  // Get active alerts
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getActiveAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Acknowledge alert
  app.patch("/api/alerts/:id/acknowledge", async (req, res) => {
    try {
      const alert = await storage.acknowledgeAlert(req.params.id);
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json(alert);
    } catch (error) {
      res.status(500).json({ error: "Failed to acknowledge alert" });
    }
  });

  // Get sensor status
  app.get("/api/sensors", async (req, res) => {
    try {
      const sensors = await storage.getSensorStatus();
      res.json(sensors);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sensor status" });
    }
  });

  // Get testing schedule
  app.get("/api/schedule", async (req, res) => {
    try {
      const schedule = await storage.getTestingSchedule();
      res.json(schedule);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch testing schedule" });
    }
  });

  // Update testing schedule
  app.patch("/api/schedule", async (req, res) => {
    try {
      const schedule = await storage.updateTestingSchedule(req.body);
      
      // Update scheduler with new interval
      if (req.body.intervalMinutes) {
        await sepsisScheduler.updateSchedule(req.body.intervalMinutes);
      }
      
      res.json(schedule);
    } catch (error) {
      res.status(500).json({ error: "Failed to update testing schedule" });
    }
  });

  // Run manual sepsis test
  app.post("/api/test/manual", async (req, res) => {
    try {
      const { patientId } = req.body;
      const result = await sepsisScheduler.runManualTest(patientId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to run manual test" });
    }
  });

  // Dashboard stats endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const patients = await storage.getPatients();
      const alerts = await storage.getActiveAlerts();
      const schedule = await storage.getTestingSchedule();
      
      const highRiskPatients = patients.filter(p => 
        p.latestTest && p.latestTest.riskScore >= (schedule?.warningThreshold || 65)
      );
      
      const criticalPatients = patients.filter(p => 
        p.latestTest && p.latestTest.riskScore >= (schedule?.criticalThreshold || 85)
      );

      const todayTests = patients.reduce((total, p) => {
        if (p.latestTest && 
            new Date(p.latestTest.timestamp).toDateString() === new Date().toDateString()) {
          return total + 1;
        }
        return total;
      }, 0);

      res.json({
        activePatients: patients.length,
        highRiskCount: highRiskPatients.length,
        criticalCount: criticalPatients.length,
        testsToday: todayTests,
        activeAlerts: alerts.length,
        avgResponseTime: "2.3min", // Mock data
        systemUptime: "127:45:32", // Mock data
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  return httpServer;
}
