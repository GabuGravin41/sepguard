import { type Vitals, type Patient } from "@shared/schema";

export interface ModelPrediction {
  modelName: string;
  prediction: number;
  confidence: number;
}

export interface SepsisRiskAssessment {
  riskScore: number;
  riskLevel: "low" | "moderate" | "high" | "critical";
  modelPredictions: ModelPrediction[];
  ensemblePrediction: number;
  recommendedActions: string[];
}

export function calculateSepsisRisk(vitals: Vitals, patient: Patient): SepsisRiskAssessment {
  // Implementation based on the research notebooks provided
  let riskScore = 0;
  
  // Age factor - older patients have higher risk
  if (patient.age > 65) riskScore += 15;
  else if (patient.age > 50) riskScore += 10;
  
  // Gender factor (from research: sex_0male_1female)
  if (patient.gender === 0) riskScore += 5; // Males slightly higher risk
  
  // Episode number factor
  if (patient.episodeNumber > 1) riskScore += 10;
  
  // Heart rate factor
  if (vitals.heartRate && vitals.heartRate > 100) riskScore += 20;
  else if (vitals.heartRate && vitals.heartRate > 90) riskScore += 10;
  
  // Temperature factor
  if (vitals.temperature) {
    if (vitals.temperature > 38.5 || vitals.temperature < 36) riskScore += 25;
    else if (vitals.temperature > 37.5) riskScore += 15;
  }
  
  // Blood pressure factor
  if (vitals.systolicBP && vitals.systolicBP < 90) riskScore += 20;
  else if (vitals.systolicBP && vitals.systolicBP < 100) riskScore += 10;
  
  // Mean arterial pressure (critical indicator from research)
  if (vitals.meanArterialPressure && vitals.meanArterialPressure < 65) riskScore += 25;
  
  // Oxygen saturation factor
  if (vitals.oxygenSaturation && vitals.oxygenSaturation < 90) riskScore += 25;
  else if (vitals.oxygenSaturation && vitals.oxygenSaturation < 95) riskScore += 15;
  
  // Respiratory rate factor
  if (vitals.respiratoryRate && vitals.respiratoryRate > 22) riskScore += 15;
  
  // Ensure score is within 0-100 range
  riskScore = Math.max(0, Math.min(100, riskScore));
  
  // Determine risk level
  let riskLevel: "low" | "moderate" | "high" | "critical";
  if (riskScore >= 85) riskLevel = "critical";
  else if (riskScore >= 65) riskLevel = "high";
  else if (riskScore >= 40) riskLevel = "moderate";
  else riskLevel = "low";

  // Simulate different ML model predictions (in real implementation, these would call actual ML models)
  const baseVariation = Math.random() * 10 - 5; // -5 to +5 variation
  
  const modelPredictions: ModelPrediction[] = [
    { 
      modelName: "Logistic Regression", 
      prediction: Math.max(0, Math.min(100, riskScore + baseVariation)), 
      confidence: 0.92 
    },
    { 
      modelName: "Random Forest", 
      prediction: Math.max(0, Math.min(100, riskScore + baseVariation * 0.8)), 
      confidence: 0.87 
    },
    { 
      modelName: "Neural Network", 
      prediction: Math.max(0, Math.min(100, riskScore + baseVariation * 1.2)), 
      confidence: 0.85 
    },
  ];

  const ensemblePrediction = modelPredictions.reduce((sum, pred) => sum + pred.prediction, 0) / modelPredictions.length;

  const recommendedActions: string[] = [];
  if (riskLevel === "critical") {
    recommendedActions.push("Immediate medical attention required");
    recommendedActions.push("Contact attending physician");
    recommendedActions.push("Consider antibiotic therapy");
    recommendedActions.push("Increase monitoring frequency");
  } else if (riskLevel === "high") {
    recommendedActions.push("Monitor closely");
    recommendedActions.push("Consider additional testing");
    recommendedActions.push("Notify medical team");
  } else if (riskLevel === "moderate") {
    recommendedActions.push("Continue monitoring");
    recommendedActions.push("Review patient history");
  }

  return {
    riskScore,
    riskLevel,
    modelPredictions,
    ensemblePrediction,
    recommendedActions,
  };
}
