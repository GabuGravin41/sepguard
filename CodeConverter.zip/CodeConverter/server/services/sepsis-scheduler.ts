import cron from 'node-cron';
import { storage } from '../storage';
import { calculateSepsisRisk } from './sepsis-prediction';
import { WebSocket } from 'ws';

export class SepsisScheduler {
  private currentTask: cron.ScheduledTask | null = null;
  private wsClients: Set<WebSocket> = new Set();

  addWebSocketClient(ws: WebSocket) {
    this.wsClients.add(ws);
    ws.on('close', () => {
      this.wsClients.delete(ws);
    });
  }

  private broadcast(data: any) {
    const message = JSON.stringify(data);
    this.wsClients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  async startScheduler() {
    const schedule = await storage.getTestingSchedule();
    if (!schedule || !schedule.isActive) return;

    const cronExpression = this.getCronExpression(schedule.intervalMinutes);
    
    this.currentTask = cron.schedule(cronExpression, async () => {
      await this.runAutomatedTests();
    });

    console.log(`Sepsis testing scheduler started with ${schedule.intervalMinutes} minute intervals`);
    this.broadcast({ type: 'scheduler_status', status: 'started', interval: schedule.intervalMinutes });
  }

  async stopScheduler() {
    if (this.currentTask) {
      this.currentTask.stop();
      this.currentTask = null;
      console.log('Sepsis testing scheduler stopped');
      this.broadcast({ type: 'scheduler_status', status: 'stopped' });
    }
  }

  async updateSchedule(intervalMinutes: number) {
    await this.stopScheduler();
    await storage.updateTestingSchedule({ 
      intervalMinutes,
      nextRun: new Date(Date.now() + intervalMinutes * 60 * 1000)
    });
    await this.startScheduler();
  }

  private getCronExpression(intervalMinutes: number): string {
    if (intervalMinutes < 60) {
      return `*/${intervalMinutes} * * * *`;
    } else {
      const hours = Math.floor(intervalMinutes / 60);
      return `0 */${hours} * * *`;
    }
  }

  async runAutomatedTests() {
    console.log('Running automated sepsis tests...');
    
    try {
      const patients = await storage.getPatients();
      const schedule = await storage.getTestingSchedule();
      let testsRun = 0;
      let alertsGenerated = 0;

      for (const patient of patients) {
        if (!patient.latestVitals) continue;

        const riskAssessment = calculateSepsisRisk(patient.latestVitals, patient);
        
        // Create sepsis test record
        await storage.createSepsisTest({
          patientId: patient.patientId,
          riskScore: riskAssessment.riskScore,
          modelPredictions: JSON.stringify(riskAssessment.modelPredictions),
          confidence: riskAssessment.ensemblePrediction,
          isAutomatic: true,
        });

        testsRun++;

        // Generate alerts based on risk level and thresholds
        if (schedule && riskAssessment.riskScore >= schedule.criticalThreshold) {
          await storage.createAlert({
            patientId: patient.patientId,
            type: 'critical',
            message: `Critical sepsis risk detected - ${riskAssessment.riskScore.toFixed(1)}% risk score`,
            acknowledged: false,
          });
          alertsGenerated++;
        } else if (schedule && riskAssessment.riskScore >= schedule.warningThreshold) {
          await storage.createAlert({
            patientId: patient.patientId,
            type: 'warning',
            message: `Elevated sepsis risk detected - ${riskAssessment.riskScore.toFixed(1)}% risk score`,
            acknowledged: false,
          });
          alertsGenerated++;
        }
      }

      // Update schedule with last run time
      await storage.updateTestingSchedule({
        lastRun: new Date(),
        nextRun: new Date(Date.now() + (schedule?.intervalMinutes || 120) * 60 * 1000),
      });

      console.log(`Automated testing completed: ${testsRun} tests run, ${alertsGenerated} alerts generated`);
      
      // Broadcast test completion
      this.broadcast({
        type: 'automated_test_complete',
        testsRun,
        alertsGenerated,
        timestamp: new Date().toISOString(),
      });

    } catch (error) {
      console.error('Error running automated tests:', error);
      this.broadcast({
        type: 'automated_test_error',
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  }

  async runManualTest(patientId?: string) {
    console.log(`Running manual sepsis test${patientId ? ` for patient ${patientId}` : ''}...`);
    
    try {
      if (patientId) {
        const patient = await storage.getPatientByPatientId(patientId);
        if (!patient) throw new Error('Patient not found');

        const patientWithVitals = await storage.getPatient(patient.id);
        if (!patientWithVitals?.latestVitals) throw new Error('No vitals available');

        const riskAssessment = calculateSepsisRisk(patientWithVitals.latestVitals, patientWithVitals);
        
        await storage.createSepsisTest({
          patientId: patient.patientId,
          riskScore: riskAssessment.riskScore,
          modelPredictions: JSON.stringify(riskAssessment.modelPredictions),
          confidence: riskAssessment.ensemblePrediction,
          isAutomatic: false,
        });

        this.broadcast({
          type: 'manual_test_complete',
          patientId,
          riskAssessment,
          timestamp: new Date().toISOString(),
        });

        return riskAssessment;
      } else {
        // Run for all patients
        return await this.runAutomatedTests();
      }
    } catch (error) {
      console.error('Error running manual test:', error);
      throw error;
    }
  }
}

export const sepsisScheduler = new SepsisScheduler();
