import { storage } from '../storage';
import { WebSocket } from 'ws';
import { calculateSepsisRisk } from './sepsis-prediction';

export class SensorSimulator {
  private wsClients: Set<WebSocket> = new Set();
  private simulationInterval: NodeJS.Timeout | null = null;

  addWebSocketClient(ws: WebSocket) {
    this.wsClients.add(ws);
    ws.on('close', () => {
      this.wsClients.delete(ws);
    });
  }

  private broadcast(data: any) {
    const message = JSON.stringify(data);
    this.wsClients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  startSimulation() {
    this.simulationInterval = setInterval(async () => {
      await this.generateSensorData();
    }, 5000); // Update every 5 seconds

    console.log('Sensor simulation started');
  }

  stopSimulation() {
    if (this.simulationInterval) {
      clearInterval(this.simulationInterval);
      this.simulationInterval = null;
      console.log('Sensor simulation stopped');
    }
  }

  private async generateSensorData() {
    try {
      const patients = await storage.getPatients();
      
      for (const patient of patients) {
        // Simulate sensor readings with some variation
        const baseVitals = this.getBaseVitals(patient.latestVitals);
        const newVitals = this.simulateVitalChanges(baseVitals);

        // Create new vitals record
        await storage.createVitals({
          patientId: patient.patientId,
          heartRate: newVitals.heartRate,
          temperature: newVitals.temperature,
          systolicBP: newVitals.systolicBP,
          diastolicBP: newVitals.diastolicBP,
          meanArterialPressure: newVitals.meanArterialPressure,
          oxygenSaturation: newVitals.oxygenSaturation,
          respiratoryRate: newVitals.respiratoryRate,
          isManual: false,
        });

        // Update sensor status randomly
        await this.updateSensorStatuses(patient.patientId);

        // Broadcast real-time update
        this.broadcast({
          type: 'vitals_update',
          patientId: patient.patientId,
          vitals: newVitals,
          timestamp: new Date().toISOString(),
        });
      }
    } catch (error) {
      console.error('Error generating sensor data:', error);
    }
  }

  private getBaseVitals(currentVitals?: any) {
    return {
      heartRate: currentVitals?.heartRate || 80,
      temperature: currentVitals?.temperature || 36.8,
      systolicBP: currentVitals?.systolicBP || 120,
      diastolicBP: currentVitals?.diastolicBP || 70,
      meanArterialPressure: currentVitals?.meanArterialPressure || 85,
      oxygenSaturation: currentVitals?.oxygenSaturation || 98,
      respiratoryRate: currentVitals?.respiratoryRate || 16,
    };
  }

  private simulateVitalChanges(baseVitals: any) {
    // Add realistic variation to vital signs
    return {
      heartRate: this.addVariation(baseVitals.heartRate, 5, 60, 180),
      temperature: this.addVariation(baseVitals.temperature, 0.3, 35, 42),
      systolicBP: this.addVariation(baseVitals.systolicBP, 8, 80, 200),
      diastolicBP: this.addVariation(baseVitals.diastolicBP, 5, 40, 120),
      meanArterialPressure: this.addVariation(baseVitals.meanArterialPressure, 6, 50, 150),
      oxygenSaturation: this.addVariation(baseVitals.oxygenSaturation, 2, 85, 100),
      respiratoryRate: this.addVariation(baseVitals.respiratoryRate, 2, 10, 35),
    };
  }

  private addVariation(value: number, maxVariation: number, min: number, max: number): number {
    const variation = (Math.random() - 0.5) * 2 * maxVariation;
    const newValue = value + variation;
    return Math.max(min, Math.min(max, newValue));
  }

  private async updateSensorStatuses(patientId: string) {
    const sensorTypes = ['heart_rate', 'temperature', 'blood_pressure', 'oxygen'];
    
    for (const sensorType of sensorTypes) {
      // Randomly simulate sensor issues (5% chance of warning, 1% chance of offline)
      const random = Math.random();
      let status = 'online';
      
      if (random < 0.01) {
        status = 'offline';
      } else if (random < 0.06) {
        status = 'warning';
      }

      await storage.updateSensorStatus(patientId, sensorType, status);
    }
  }
}

// Sepsis prediction algorithm based on the research data
function calculateSepsisRisk(vitals: any, patient: any) {
  // Simplified implementation based on the research notebooks
  let riskScore = 0;
  
  // Age factor (older patients have higher risk)
  if (patient.age > 65) riskScore += 15;
  else if (patient.age > 50) riskScore += 10;
  
  // Heart rate factor
  if (vitals.heartRate > 100) riskScore += 20;
  else if (vitals.heartRate > 90) riskScore += 10;
  
  // Temperature factor
  if (vitals.temperature > 38.5 || vitals.temperature < 36) riskScore += 25;
  else if (vitals.temperature > 37.5) riskScore += 15;
  
  // Blood pressure factor
  if (vitals.systolicBP < 90) riskScore += 20;
  else if (vitals.systolicBP < 100) riskScore += 10;
  
  // Oxygen saturation factor
  if (vitals.oxygenSaturation < 90) riskScore += 25;
  else if (vitals.oxygenSaturation < 95) riskScore += 15;
  
  // Respiratory rate factor
  if (vitals.respiratoryRate > 22) riskScore += 15;
  
  // Ensure score is within 0-100 range
  riskScore = Math.max(0, Math.min(100, riskScore));
  
  // Determine risk level
  let riskLevel: "low" | "moderate" | "high" | "critical";
  if (riskScore >= 85) riskLevel = "critical";
  else if (riskScore >= 65) riskLevel = "high";
  else if (riskScore >= 40) riskLevel = "moderate";
  else riskLevel = "low";

  // Mock model predictions (in real implementation, these would call actual ML models)
  const modelPredictions = [
    { modelName: "Logistic Regression", prediction: riskScore + Math.random() * 10 - 5, confidence: 0.92 },
    { modelName: "Random Forest", prediction: riskScore + Math.random() * 8 - 4, confidence: 0.87 },
    { modelName: "Neural Network", prediction: riskScore + Math.random() * 12 - 6, confidence: 0.85 },
  ];

  const ensemblePrediction = modelPredictions.reduce((sum, pred) => sum + pred.prediction, 0) / modelPredictions.length;

  const recommendedActions = [];
  if (riskLevel === "critical") {
    recommendedActions.push("Immediate medical attention required");
    recommendedActions.push("Contact attending physician");
    recommendedActions.push("Consider antibiotic therapy");
    recommendedActions.push("Increase monitoring frequency");
  } else if (riskLevel === "high") {
    recommendedActions.push("Monitor closely");
    recommendedActions.push("Consider additional testing");
    recommendedActions.push("Notify medical team");
  }

  return {
    riskScore,
    riskLevel,
    modelPredictions,
    ensemblePrediction,
    recommendedActions,
  };
}

export const sensorSimulator = new SensorSimulator();
