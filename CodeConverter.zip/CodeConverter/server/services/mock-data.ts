import { storage } from '../storage';
import { randomUUID } from 'crypto';

export async function initializeMockData() {
  console.log('Initializing mock patient data...');

  // Create sample patients
  const samplePatients = [
    {
      name: "Sarah Johnson",
      patientId: "A-4423",
      room: "304-A",
      age: 67,
      gender: 0, // Female
      episodeNumber: 2,
      admissionDate: new Date('2024-01-15'),
    },
    {
      name: "Michael Chen",
      patientId: "B-7891",
      room: "301-B",
      age: 54,
      gender: 1, // Male
      episodeNumber: 1,
      admissionDate: new Date('2024-01-16'),
    },
    {
      name: "Emma Rodriguez",
      patientId: "C-1156",
      room: "302-C",
      age: 42,
      gender: 0, // Female
      episodeNumber: 1,
      admissionDate: new Date('2024-01-17'),
    },
    {
      name: "David Thompson",
      patientId: "D-2234",
      room: "305-A",
      age: 78,
      gender: 1, // Male
      episodeNumber: 3,
      admissionDate: new Date('2024-01-14'),
    },
    {
      name: "Lisa Park",
      patientId: "E-5567",
      room: "303-B",
      age: 33,
      gender: 0, // Female
      episodeNumber: 1,
      admissionDate: new Date('2024-01-18'),
    },
  ];

  // Create patients and initial vitals
  for (const patientData of samplePatients) {
    const patient = await storage.createPatient(patientData);

    // Create initial vitals based on risk profile
    let baseVitals;
    if (patient.name === "Sarah Johnson") {
      // High-risk patient
      baseVitals = {
        heartRate: 128,
        temperature: 39.2,
        systolicBP: 85,
        diastolicBP: 55,
        meanArterialPressure: 65,
        oxygenSaturation: 88,
        respiratoryRate: 24,
      };
    } else if (patient.name === "Michael Chen") {
      // Moderate-risk patient
      baseVitals = {
        heartRate: 105,
        temperature: 38.1,
        systolicBP: 120,
        diastolicBP: 78,
        meanArterialPressure: 92,
        oxygenSaturation: 95,
        respiratoryRate: 20,
      };
    } else {
      // Low-risk patient
      baseVitals = {
        heartRate: 78,
        temperature: 36.8,
        systolicBP: 118,
        diastolicBP: 72,
        meanArterialPressure: 87,
        oxygenSaturation: 98,
        respiratoryRate: 16,
      };
    }

    await storage.createVitals({
      patientId: patient.patientId,
      ...baseVitals,
      isManual: false,
    });

    // Initialize sensor statuses
    const sensorTypes = ['heart_rate', 'temperature', 'blood_pressure', 'oxygen'];
    for (const sensorType of sensorTypes) {
      const status = Math.random() > 0.1 ? 'online' : Math.random() > 0.5 ? 'warning' : 'offline';
      await storage.updateSensorStatus(patient.patientId, sensorType, status);
    }
  }

  console.log(`Initialized ${samplePatients.length} patients with vitals and sensor data`);
}
