import { 
  type Patient, 
  type InsertPatient,
  type Vitals,
  type InsertVitals,
  type SepsisTest,
  type InsertSepsisTest,
  type Alert,
  type InsertAlert,
  type SensorStatus,
  type InsertSensorStatus,
  type TestingSchedule,
  type InsertTestingSchedule,
  type PatientWithVitals
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Patient operations
  getPatients(): Promise<PatientWithVitals[]>;
  getPatient(id: string): Promise<PatientWithVitals | undefined>;
  getPatientByPatientId(patientId: string): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  updatePatient(id: string, patient: Partial<Patient>): Promise<Patient | undefined>;

  // Vitals operations
  getLatestVitals(patientId: string): Promise<Vitals | undefined>;
  getVitalsHistory(patientId: string, limit?: number): Promise<Vitals[]>;
  createVitals(vitals: InsertVitals): Promise<Vitals>;

  // Sepsis tests operations
  getLatestSepsisTest(patientId: string): Promise<SepsisTest | undefined>;
  getSepsisTestHistory(patientId: string, limit?: number): Promise<SepsisTest[]>;
  createSepsisTest(test: InsertSepsisTest): Promise<SepsisTest>;

  // Alerts operations
  getActiveAlerts(): Promise<Alert[]>;
  getPatientAlerts(patientId: string): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  acknowledgeAlert(id: string): Promise<Alert | undefined>;

  // Sensor status operations
  getSensorStatus(): Promise<SensorStatus[]>;
  updateSensorStatus(patientId: string, sensorType: string, status: string): Promise<SensorStatus>;

  // Testing schedule operations
  getTestingSchedule(): Promise<TestingSchedule | undefined>;
  updateTestingSchedule(schedule: Partial<TestingSchedule>): Promise<TestingSchedule>;
}

export class MemStorage implements IStorage {
  private patients: Map<string, Patient> = new Map();
  private vitals: Map<string, Vitals[]> = new Map();
  private sepsisTests: Map<string, SepsisTest[]> = new Map();
  private alerts: Map<string, Alert> = new Map();
  private sensorStatuses: Map<string, SensorStatus> = new Map();
  private testingScheduleData: TestingSchedule | undefined;

  constructor() {
    // Initialize default testing schedule
    this.testingScheduleData = {
      id: randomUUID(),
      intervalMinutes: 120,
      isActive: true,
      lastRun: null,
      nextRun: new Date(Date.now() + 120 * 60 * 1000),
      criticalThreshold: 85,
      warningThreshold: 65,
      audioAlerts: true,
      emailNotifications: true,
      smsAlerts: false,
    };
  }

  async getPatients(): Promise<PatientWithVitals[]> {
    const patientsWithVitals: PatientWithVitals[] = [];
    
    for (const patient of this.patients.values()) {
      const latestVitals = await this.getLatestVitals(patient.patientId);
      const latestTest = await this.getLatestSepsisTest(patient.patientId);
      const patientAlerts = await this.getPatientAlerts(patient.patientId);
      const alertCount = patientAlerts.filter(a => !a.acknowledged).length;

      patientsWithVitals.push({
        ...patient,
        latestVitals,
        latestTest,
        alertCount,
      });
    }

    return patientsWithVitals;
  }

  async getPatient(id: string): Promise<PatientWithVitals | undefined> {
    const patient = this.patients.get(id);
    if (!patient) return undefined;

    const latestVitals = await this.getLatestVitals(patient.patientId);
    const latestTest = await this.getLatestSepsisTest(patient.patientId);
    const patientAlerts = await this.getPatientAlerts(patient.patientId);
    const alertCount = patientAlerts.filter(a => !a.acknowledged).length;

    return {
      ...patient,
      latestVitals,
      latestTest,
      alertCount,
    };
  }

  async getPatientByPatientId(patientId: string): Promise<Patient | undefined> {
    return Array.from(this.patients.values()).find(p => p.patientId === patientId);
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const id = randomUUID();
    const patient: Patient = {
      ...insertPatient,
      id,
      createdAt: new Date(),
    };
    this.patients.set(id, patient);
    return patient;
  }

  async updatePatient(id: string, updates: Partial<Patient>): Promise<Patient | undefined> {
    const patient = this.patients.get(id);
    if (!patient) return undefined;

    const updatedPatient = { ...patient, ...updates };
    this.patients.set(id, updatedPatient);
    return updatedPatient;
  }

  async getLatestVitals(patientId: string): Promise<Vitals | undefined> {
    const patientVitals = this.vitals.get(patientId) || [];
    return patientVitals.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
  }

  async getVitalsHistory(patientId: string, limit = 50): Promise<Vitals[]> {
    const patientVitals = this.vitals.get(patientId) || [];
    return patientVitals
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async createVitals(insertVitals: InsertVitals): Promise<Vitals> {
    const id = randomUUID();
    const vitals: Vitals = {
      ...insertVitals,
      id,
      timestamp: new Date(),
    };

    const patientVitals = this.vitals.get(insertVitals.patientId) || [];
    patientVitals.push(vitals);
    this.vitals.set(insertVitals.patientId, patientVitals);

    return vitals;
  }

  async getLatestSepsisTest(patientId: string): Promise<SepsisTest | undefined> {
    const patientTests = this.sepsisTests.get(patientId) || [];
    return patientTests.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
  }

  async getSepsisTestHistory(patientId: string, limit = 20): Promise<SepsisTest[]> {
    const patientTests = this.sepsisTests.get(patientId) || [];
    return patientTests
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async createSepsisTest(insertTest: InsertSepsisTest): Promise<SepsisTest> {
    const id = randomUUID();
    const test: SepsisTest = {
      ...insertTest,
      id,
      timestamp: new Date(),
    };

    const patientTests = this.sepsisTests.get(insertTest.patientId) || [];
    patientTests.push(test);
    this.sepsisTests.set(insertTest.patientId, patientTests);

    return test;
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => !alert.acknowledged)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getPatientAlerts(patientId: string): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.patientId === patientId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = {
      ...insertAlert,
      id,
      timestamp: new Date(),
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async acknowledgeAlert(id: string): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;

    const acknowledgedAlert = { ...alert, acknowledged: true };
    this.alerts.set(id, acknowledgedAlert);
    return acknowledgedAlert;
  }

  async getSensorStatus(): Promise<SensorStatus[]> {
    return Array.from(this.sensorStatuses.values());
  }

  async updateSensorStatus(patientId: string, sensorType: string, status: string): Promise<SensorStatus> {
    const key = `${patientId}-${sensorType}`;
    const existingStatus = this.sensorStatuses.get(key);

    const sensorStatus: SensorStatus = {
      id: existingStatus?.id || randomUUID(),
      sensorType,
      patientId,
      status,
      lastUpdate: new Date(),
    };

    this.sensorStatuses.set(key, sensorStatus);
    return sensorStatus;
  }

  async getTestingSchedule(): Promise<TestingSchedule | undefined> {
    return this.testingScheduleData;
  }

  async updateTestingSchedule(updates: Partial<TestingSchedule>): Promise<TestingSchedule> {
    if (!this.testingScheduleData) {
      throw new Error("No testing schedule found");
    }

    this.testingScheduleData = {
      ...this.testingScheduleData,
      ...updates,
    };

    return this.testingScheduleData;
  }
}

export const storage = new MemStorage();
