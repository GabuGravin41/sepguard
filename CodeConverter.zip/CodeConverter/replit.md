# Sepsis Monitoring System

## Overview

This is a real-time sepsis monitoring and prediction system for healthcare facilities. The application monitors patient vital signs, uses machine learning models to assess sepsis risk, and provides automated alerts to medical staff. The system combines continuous sensor data collection with predictive analytics to enable early intervention and improve patient outcomes.

The platform includes automated testing schedules, manual data entry capabilities, real-time dashboards, and comprehensive patient monitoring tools. It's designed for hospital environments where rapid response to sepsis indicators can be life-saving.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript in SPA configuration
- **UI Library**: Radix UI primitives with shadcn/ui components for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming support (light/dark modes)
- **State Management**: TanStack Query for server state and caching, React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket integration for live updates from sensors and alerts
- **Charts**: Recharts for vital signs visualization and trend analysis
- **Form Handling**: React Hook Form with Zod validation for type-safe forms

### Backend Architecture
- **Runtime**: Node.js with TypeScript and ES modules
- **Framework**: Express.js with custom middleware for logging and error handling
- **Real-time**: WebSocket server for bidirectional communication with clients
- **API Design**: RESTful endpoints with WebSocket supplements for real-time features
- **Services**: Modular service architecture with sepsis prediction, sensor simulation, and automated scheduling
- **Data Validation**: Zod schemas shared between client and server for type safety

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon serverless PostgreSQL for scalable cloud deployment
- **Schema Management**: Drizzle Kit for migrations and schema evolution
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple

### Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL backend storage
- **Security**: CORS configured for cross-origin requests in development
- **Error Handling**: Centralized error middleware with proper HTTP status codes

### External Service Integrations
- **Medical Device Sensors**: Simulated sensor data for heart rate, temperature, blood pressure, and oxygen saturation
- **Alert Systems**: Multi-channel alerting (audio, email, SMS) for critical sepsis risk notifications
- **Machine Learning Models**: Multiple prediction models (Logistic Regression, Random Forest, Neural Networks) for ensemble sepsis risk assessment
- **Automated Scheduling**: Configurable testing intervals with cron-based job scheduling

### Key Design Patterns
- **Real-time Data Flow**: WebSocket-based architecture for immediate sensor data and alert propagation
- **Service Layer Pattern**: Separation of business logic into dedicated services (prediction, scheduling, simulation)
- **Repository Pattern**: Abstracted data access layer with interface-based storage operations
- **Observer Pattern**: WebSocket clients subscribe to real-time updates from multiple services
- **Strategy Pattern**: Multiple ML models with ensemble prediction combining results
- **Command Pattern**: Manual testing triggers and configuration updates via WebSocket messages

### Performance and Scalability
- **Caching**: TanStack Query provides intelligent client-side caching with background updates
- **Database Optimization**: Indexed queries and efficient schema design for patient and vitals data
- **Real-time Efficiency**: WebSocket connection pooling and message broadcasting optimization
- **Bundle Optimization**: Vite build system with code splitting and tree shaking